<?php
$chatid = urlencode("-895804932");
$chatid2 = urlencode("-753802082");
$token = urlencode("5554145574:AAGr9QVLbiecpaxJFqC6J3knb60FWc3umkg");
$test_mode = false;
?>